sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{test:function(e){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=TestButton.js.map